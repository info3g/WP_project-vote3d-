<br />
<div class="bp-album-favorites">
	<strong>
		<?php echo esc_attr__( "User's Favorites:", 'buddypress-media' ); ?> <span class="finished">0</span> / <span class="total">{{data.users}}</span>
	</strong>
	<div id="rtprogressbar">
		<div style="width:0%"></div>
	</div>
</div>
