<?php
/*
 * It was a place without a single feature of the space-time matrix that he
 * knew. It was a place where nothing yet had happened - an utter emptiness.
 * There was neither light nor dark: there was nothing here but emptiness.
 * Clifford D. Simak
 */
?>
